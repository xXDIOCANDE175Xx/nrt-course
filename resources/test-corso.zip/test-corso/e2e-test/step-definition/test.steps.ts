import { OurWorld } from '@rgi/playwright-globalshare-lib'
import { Then } from '@cucumber/cucumber'

Then('test', async function (this: OurWorld) {
    console.log('aaaaaaa')
})
