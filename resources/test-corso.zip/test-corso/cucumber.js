const environments = require('./environment.js');

const default_Parameters = {
  basePPOUrl: process.env.BASE_PPO_URL || environments.AUTO_Parameters.basePPOUrl,
  basePIUrl: process.env.BASE_PI_URL || environments.AUTO_Parameters.basePIUrl,
  PIContext: process.env.PI_CONTEXT || environments.AUTO_Parameters.PIContext

}

const common = `
  --require-module ts-node/register
  --require e2e-test/step-definitions/**/*.ts
  --require node_modules/@rgi/playwright-cucumber-runner-lib
  --require node_modules/@rgi/playwright-globalshare-lib
  --require node_modules/@rgi/playwright-performance-lib
  --require node_modules/@rgi/playwright-getinfo-lib
  --format summary 
  --format progress-bar 
  --format-options ${JSON.stringify({ snippetInterface: 'async-await' })}
  --publish-quiet
  `;
// --format json:output/report.json 
// --format message:output/report.ndjson
module.exports = {
  default: `${common} --world-parameters '${JSON.stringify(default_Parameters)}'`,
  auto: `${common} --world-parameters '${JSON.stringify(environments.AUTO_Parameters)}'`,
  manual: `${common} --world-parameters '${JSON.stringify(environments.MANUAL_Parameters)}'`,
  maintenance: `${common} --world-parameters '${JSON.stringify(environments.MAINTENANCE_Parameters)}'`
};