// Environment configuration. Used to run test on differenst application instance


module.exports = {

  AUTO_Parameters: {
    basePPOUrl: "http://tox-realeci01-pltf.ad.rgigroup.com:8100/",
    basePIUrl: "http://tox-realeci01-pltf.ad.rgigroup.com:8080/"
  }
}

